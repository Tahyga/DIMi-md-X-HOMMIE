'use strict';
/**
 * manager.js
 *
 * Keeps every linked WhatsApp number alive (one socket per number) and handles
 * the "enter your number -> get a pairing code" flow.
 *
 *  - Credentials are stored on disk in SESSIONS_DIR/<number>/ (never in a Session ID).
 *  - On boot, every registered number found on disk is reconnected automatically.
 *  - Unfinished pairings are cleaned up after PAIR_TIMEOUT_MS.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const pino = require('pino');
const site = require('./site');
const handler = require('./handler');

const SESSIONS_DIR = process.env.SESSIONS_DIR || path.join(process.cwd(), 'sessions');
try { fs.mkdirSync(SESSIONS_DIR, { recursive: true }); } catch (e) { /* ignore */ }

const PAIR_TIMEOUT_MS = 3 * 60 * 1000; // a pairing code is only valid for a few minutes
const MAX_RETRIES = 8;
const logger = pino({ level: process.env.LOG_LEVEL || 'silent' });

const sessions = new Map(); // number -> entry (live sockets)
const results = new Map();  // token  -> { status, error, t }  (what the web page polls)

class PairError extends Error {
    constructor(status, message) {
        super(message);
        this.status = status;
    }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- library loader (baileys fork is ESM, this project is CommonJS) ----------
let _lib;
function lib() {
    if (!_lib) {
        _lib = (async () => {
            const b = await import('@whiskeysockets/baileys');
            const pick = (k) => b[k] ?? (b.default && b.default[k]);
            return {
                makeWASocket: b.makeWASocket || b.default,
                useMultiFileAuthState: pick('useMultiFileAuthState'),
                makeCacheableSignalKeyStore: pick('makeCacheableSignalKeyStore'),
                fetchLatestBaileysVersion: pick('fetchLatestBaileysVersion'),
                Browsers: pick('Browsers'),
                DisconnectReason: pick('DisconnectReason'),
                jidNormalizedUser: pick('jidNormalizedUser'),
            };
        })();
    }
    return _lib;
}

// ---------- helpers ----------
function normalizeNumber(input) {
    const n = String(input || '').replace(/[^0-9]/g, '');
    if (n.length < 8 || n.length > 15) {
        throw new PairError(400, 'Nimewo a pa valid. Mete l ak kòd peyi a, san + ni espas (egzanp: 50937123456).');
    }
    return n;
}
const dirOf = (number) => path.join(SESSIONS_DIR, number); // number is digits only -> safe path
function wipe(number) {
    try { fs.rmSync(dirOf(number), { recursive: true, force: true }); } catch (e) { /* ignore */ }
}
function report(entry, status, error) {
    if (!entry.token) return;
    const r = results.get(entry.token);
    if (r) { r.status = status; r.error = error || null; }
}
function getStatus(token) {
    const r = results.get(String(token || ''));
    return r ? { status: r.status, error: r.error } : { status: 'not_found' };
}
function count() {
    let connected = 0;
    for (const e of sessions.values()) if (e.status === 'connected') connected++;
    return { connected, total: sessions.size };
}

// forget a live entry and close its socket (does not touch files)
function drop(number, entry) {
    entry.stopping = true;
    clearTimeout(entry.timer);
    clearTimeout(entry.retryTimer);
    if (sessions.get(number) === entry) sessions.delete(number);
    try { entry.sock && entry.sock.end(undefined); } catch (e) { /* ignore */ }
}
function fail(number, entry, message, { wipeFiles = true } = {}) {
    entry.status = 'failed';
    report(entry, 'failed', message);
    drop(number, entry);
    if (wipeFiles) wipe(number);
    console.log(`[${number}] stopped: ${message}`);
}

/** Disconnect a number. logout=true also unlinks the device on WhatsApp's side and deletes the files. */
async function stop(number, { logout = false } = {}) {
    const entry = sessions.get(number);
    if (!entry) { if (logout) wipe(number); return; }
    entry.stopping = true;
    if (logout && entry.sock) {
        try { await entry.sock.logout(); } catch (e) { /* already closed */ }
    }
    drop(number, entry);
    if (logout) wipe(number);
}

// ---------- socket ----------
async function openSocket(number, entry) {
    const L = await lib();
    const { state, saveCreds } = await L.useMultiFileAuthState(dirOf(number));
    let version;
    try { ({ version } = await L.fetchLatestBaileysVersion()); } catch (e) { /* use library default */ }

    const sock = L.makeWASocket({
        ...(version ? { version } : {}),
        auth: {
            creds: state.creds,
            keys: L.makeCacheableSignalKeyStore(state.keys, logger),
        },
        logger,
        printQRInTerminal: false,
        browser: L.Browsers.ubuntu('Chrome'),
        markOnlineOnConnect: false, // so the phone keeps receiving its own notifications
        syncFullHistory: false,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
    });

    entry.sock = sock;
    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', (u) => {
        onUpdate(number, entry, sock, u).catch((e) => console.log(`[${number}] update error:`, e && e.message));
    });
    sock.ev.on('messages.upsert', (up) => {
        if (entry.sock !== sock || entry.stopping) return;
        handler.onMessages(sock, number, up).catch((e) => console.log(`[${number}] handler error:`, e && e.message));
    });
    return sock;
}

async function onUpdate(number, entry, sock, update) {
    if (entry.sock !== sock || entry.stopping) return; // event from an old socket
    const { connection, lastDisconnect } = update;

    if (connection === 'open') {
        entry.status = 'connected';
        entry.retries = 0;
        clearTimeout(entry.timer);
        report(entry, 'connected');
        console.log(`[${number}] connected (${count().connected} active)`);
        if (entry.fresh) {
            entry.fresh = false;
            sendWelcome(sock).catch((e) => console.log(`[${number}] welcome failed:`, e && e.message));
        }
        return;
    }

    if (connection === 'close') {
        const L = await lib();
        const DR = L.DisconnectReason;
        const code = lastDisconnect && lastDisconnect.error && lastDisconnect.error.output
            ? lastDisconnect.error.output.statusCode : undefined;
        const registered = !!(sock.authState && sock.authState.creds && sock.authState.creds.registered);

        if (code === DR.loggedOut || code === DR.forbidden) {
            return fail(number, entry, 'Aparèy la dekonekte nan WhatsApp. Konekte ankò si ou vle.');
        }
        if (code === DR.connectionReplaced) {
            return fail(number, entry, 'Sesyon sa a ap itilize yon lòt kote.', { wipeFiles: false });
        }
        if (!registered) {
            return fail(number, entry, 'Koneksyon an fèmen anvan ou fin lye aparèy la. Jenere yon nouvo kòd.');
        }
        // temporary drop (or the normal restart WhatsApp asks for right after pairing, code 515)
        scheduleReconnect(number, entry, code === DR.restartRequired ? 500 : undefined);
    }
}

function scheduleReconnect(number, entry, forcedDelay) {
    entry.retries = (entry.retries || 0) + 1;
    if (entry.retries > MAX_RETRIES) {
        // keep the files: the next server restart will try again
        return fail(number, entry, 'Pa kapab rekonekte apre plizyè eseye.', { wipeFiles: false });
    }
    if (entry.status === 'connected') entry.status = 'reconnecting';
    const wait = forcedDelay !== undefined ? forcedDelay : Math.min(30000, 1000 * 2 ** entry.retries);
    clearTimeout(entry.retryTimer);
    entry.retryTimer = setTimeout(async () => {
        if (entry.stopping) return;
        try {
            await openSocket(number, entry);
        } catch (e) {
            console.log(`[${number}] reconnect failed:`, e && e.message);
            scheduleReconnect(number, entry);
        }
    }, wait);
}

async function sendWelcome(sock) {
    await sleep(3000);
    const L = await lib();
    const jid = L.jidNormalizedUser(sock.user.id);
    await handler.sendWithLogo(sock, jid, site.bot.welcome());
}

// resolves when the server is ready to accept a pairing request (first `qr` event) or after `ms`
function waitUntilReady(sock, ms = 8000) {
    return new Promise((resolve, reject) => {
        let done = false;
        const finish = (fn, v) => {
            if (done) return;
            done = true;
            clearTimeout(t);
            try { sock.ev.off('connection.update', on); } catch (e) { /* ignore */ }
            fn(v);
        };
        const on = (u) => {
            if (u.qr) finish(resolve);
            else if (u.connection === 'close') finish(reject, new Error('connection closed'));
        };
        const t = setTimeout(() => finish(resolve), ms);
        sock.ev.on('connection.update', on);
    });
}

// ---------- public API ----------
async function startPairing(rawNumber) {
    const number = normalizeNumber(rawNumber);

    const existing = sessions.get(number);
    if (existing && existing.status === 'connected') {
        throw new PairError(409, `Nimewo sa a deja konekte ak bot la. Voye ${site.bot.prefix}menu nan WhatsApp pou itilize l.`);
    }
    if (existing) drop(number, existing); // restart a stale pairing / reconnecting entry

    if (sessions.size >= site.bot.maxSessions) {
        throw new PairError(503, 'Sèvè a plen pou kounye a. Eseye ankò pita.');
    }

    wipe(number);
    const entry = {
        number,
        status: 'pairing',
        fresh: true,
        retries: 0,
        stopping: false,
        token: crypto.randomBytes(12).toString('hex'),
        sock: null,
    };
    sessions.set(number, entry);
    results.set(entry.token, { status: 'pending', error: null, t: Date.now() });

    try {
        const sock = await openSocket(number, entry);
        await waitUntilReady(sock);
        const raw = await sock.requestPairingCode(number);
        entry.timer = setTimeout(() => {
            if (entry.status !== 'connected' && !entry.stopping) {
                fail(number, entry, 'Tan an fini. Jenere yon nouvo kòd.');
            }
        }, PAIR_TIMEOUT_MS);
        const code = String(raw).match(/.{1,4}/g).join('-');
        return { token: entry.token, code };
    } catch (e) {
        console.log(`[${number}] pairing failed:`, e && e.message);
        if (!entry.stopping) fail(number, entry, 'Pa t kapab jenere kòd la.');
        throw new PairError(503, 'Pa t kapab jenere kòd la. Verifye nimewo a epi eseye ankò nan kèk segonn.');
    }
}

async function restoreAll() {
    let dirs = [];
    try {
        dirs = fs.readdirSync(SESSIONS_DIR, { withFileTypes: true })
            .filter((d) => d.isDirectory() && /^[0-9]{8,15}$/.test(d.name))
            .map((d) => d.name);
    } catch (e) { /* no folder yet */ }

    let started = 0;
    for (const number of dirs) {
        let registered = false;
        try {
            registered = !!JSON.parse(fs.readFileSync(path.join(dirOf(number), 'creds.json'), 'utf8')).registered;
        } catch (e) { /* unreadable */ }
        if (!registered) { wipe(number); continue; } // leftover of an unfinished pairing
        if (sessions.size >= site.bot.maxSessions) {
            console.log(`[manager] limit reached (${site.bot.maxSessions}), skipping ${number}`);
            continue;
        }
        const entry = { number, status: 'reconnecting', fresh: false, retries: 0, stopping: false, token: null, sock: null };
        sessions.set(number, entry);
        try { await openSocket(number, entry); } catch (e) { scheduleReconnect(number, entry); }
        started++;
        await sleep(2000); // do not open all sockets at once
    }
    console.log(`[manager] restored ${started} session(s) from ${SESSIONS_DIR}`);
}

// forget old pairing results
setInterval(() => {
    const limit = Date.now() - 15 * 60 * 1000;
    for (const [k, v] of results) if (v.t < limit) results.delete(k);
}, 5 * 60 * 1000).unref();

module.exports = { startPairing, getStatus, restoreAll, stop, count, PairError, SESSIONS_DIR };
