'use strict';
/**
 * commands.js  —  ADD YOUR OWN COMMANDS HERE
 *
 * Each command is an object:
 *   name       command word (without prefix)
 *   aliases    other words that run the same command (optional)
 *   desc       one line shown in the menu (the menu is built automatically)
 *   hidden     true = not listed in the menu (optional)
 *   ownerOnly  true = only the owner number from clone.js can use it (optional)
 *   selfOnly   true = only the account holder (the linked number) can use it (optional)
 *   run(ctx)   the code. ctx has: sock, m, jid, number, sender, isSelf, isOwner,
 *              args, text, prefix, isGroup, reply(text), replyLogo(caption), replyVideo(caption)
 *
 * Example of a new command:
 *
 *   add({
 *       name: 'hello',
 *       desc: 'say Good morning',
 *       run: (ctx) => ctx.reply('Good morning ! 👋'),
 *   });
 *
 * IMPORTANT: a reply must never start with the command prefix (it would be
 * seen as a command again).
 */
const site = require('./site');

const registry = new Map();
const list = [];

function add(def) {
    list.push(def);
    registry.set(def.name, def);
    for (const a of def.aliases || []) registry.set(a, def);
}

const startedAt = Date.now();
function formatUptime(ms) {
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const parts = [];
    if (d) parts.push(d + ' jou');
    if (h || d) parts.push(h + ' è');
    parts.push(m + ' min');
    return parts.join(' ');
}

// ------------------------------------------------------------------ commands

add({
    name: 'menu',
    aliases: ['help', 'aide'],
    desc: 'see the listof this command',
    run: async (ctx) => {
        const p = ctx.prefix;
        const lines = list
            .filter((c) => !c.hidden)
            .map((c) => `• *${p}${c.name}* — ${c.desc}`)
            .join('\n');
        const caption =
            `╭━━〔 *${site.bot.botName}* 〕━━⬣\n` +
            (site.bot.ownerNumber ? `┃ 👑 Pwopriyetè : ${site.bot.ownerNumber}\n` : '') +
            `┃ ⚙️ Prefiks : ${p}\n` +
            `┃ ⏱️ Actif depi : ${formatUptime(Date.now() - startedAt)}\n` +
            `╰━━━━━━━━━━━━━━━━⬣\n\n` +
            `📋 *KÒMAND YO*\n${lines}`;
        await ctx.replyLogo(site.bot.withFooter(caption));
    },
});

add({
    name: 'ping',
    desc: 'Teste vitès bot la',
    run: async (ctx) => {
        const sentAt = Number(ctx.m.messageTimestamp) * 1000;
        const ms = sentAt ? Math.max(0, Date.now() - sentAt) : 0;
        await ctx.replyVideo(`🏓 Pong ! ${ms} ms`);
    },
});

add({
    name: 'alive',
    desc: 'Wè si bot la aktif',
    run: async (ctx) => {
        const caption =
            `✅ *${site.bot.botName}* aktif !\n\n` +
            `⏱️ Aktif depi : ${formatUptime(Date.now() - startedAt)}\n` +
            `Voye *${ctx.prefix}menu* pou wè kòmand yo.`;
        await ctx.replyVideo(site.bot.withFooter(caption));
    },
});

add({
    name: 'runtime',
    aliases: ['uptime'],
    desc: 'Konbyen tan bot la ap mache',
    run: (ctx) => ctx.reply(`⏱️ Bot la ap mache depi ${formatUptime(Date.now() - startedAt)}`),
});

add({
    name: 'owner',
    aliases: ['creator', 'pwopriyetè'],
    desc: 'Kontak pwopriyetè bot la',
    run: async (ctx) => {
        const { sock, jid, m } = ctx;
        if (!site.bot.ownerDigits) return ctx.reply('Pa gen pwopriyetè ki konfigire.');
        const name = site.bot.ownerName;
        const vcard =
            'BEGIN:VCARD\nVERSION:3.0\n' +
            `FN:${name}\n` +
            `TEL;type=CELL;type=VOICE;waid=${site.bot.ownerDigits}:${site.bot.ownerNumber}\n` +
            'END:VCARD';
        const res = await sock.sendMessage(jid, { contacts: { displayName: name, contacts: [{ vcard }] } }, { quoted: m });
        ctx.remember(res);
        await ctx.reply(site.bot.withFooter(`👑 Pwopriyetè : *${name}*\n📞 ${site.bot.ownerNumber}`));
    },
});

add({
    name: 'group',
    aliases: ['gwoup', 'grup'],
    desc: 'Lyen gwoup WhatsApp nou an',
    run: async (ctx) => {
        const footer = site.bot.footer();
        await ctx.reply(footer || 'Pa gen lyen gwoup ki konfigire.');
    },
});

add({
    name: 'logout',
    aliases: ['dekonekte'],
    desc: 'Dekonekte bot la sou nimewo ou (mèt kont lan sèlman)',
    selfOnly: true,
    run: async (ctx) => {
        const manager = require('./manager'); // loaded here to avoid a circular require
        await ctx.reply('👋 Bot la ap dekonekte sou nimewo sa a. Si ou vle konekte l ankò, retounen sou sit la.');
        setTimeout(() => manager.stop(ctx.number, { logout: true }).catch(() => {}), 1500);
    },
});

add({
    name: 'users',
    desc: 'Kantite nimewo ki konekte (pwopriyetè sèlman)',
    ownerOnly: true,
    run: (ctx) => {
        const manager = require('./manager');
        const c = manager.count();
        return ctx.reply(`👥 Nimewo konekte : ${c.connected}\n📦 Total sesyon : ${c.total} / ${site.bot.maxSessions}`);
    },
});

module.exports = { get: (name) => registry.get(name), list, add };
