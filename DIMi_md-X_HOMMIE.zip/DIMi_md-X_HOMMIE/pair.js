'use strict';
/**
 * pair.js  —  API used by the connection page
 *
 *   POST /code           { number }  -> { token, code }   (pairing code to type in WhatsApp)
 *   GET  /status/:token              -> { status: pending | connected | failed | not_found, error? }
 */
const express = require('express');
const manager = require('./manager');

const router = express.Router();

// ---- simple rate limit per IP: max 5 code requests every 10 minutes ----
const WINDOW_MS = 10 * 60 * 1000;
const MAX_PER_WINDOW = 5;
const hits = new Map(); // ip -> [timestamps]

function limited(ip) {
    const now = Date.now();
    const arr = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
    if (arr.length >= MAX_PER_WINDOW) {
        hits.set(ip, arr);
        return true;
    }
    arr.push(now);
    hits.set(ip, arr);
    return false;
}
setInterval(() => {
    const now = Date.now();
    for (const [ip, arr] of hits) {
        const fresh = arr.filter((t) => now - t < WINDOW_MS);
        if (fresh.length) hits.set(ip, fresh); else hits.delete(ip);
    }
}, WINDOW_MS).unref();

router.post('/code', async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (limited(req.ip)) {
        return res.status(429).json({ error: 'Twòp demann. Tann kèk minit epi eseye ankò.' });
    }
    try {
        const { token, code } = await manager.startPairing(req.body && req.body.number);
        res.json({ token, code });
    } catch (e) {
        if (e instanceof manager.PairError) return res.status(e.status).json({ error: e.message });
        console.log('pair error:', e && e.message);
        res.status(500).json({ error: 'Erè sèvè. Eseye ankò.' });
    }
});

router.get('/status/:token', (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json(manager.getStatus(req.params.token));
});

module.exports = router;
