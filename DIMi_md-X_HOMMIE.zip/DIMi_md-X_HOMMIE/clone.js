/**
 * ======================================================
 *  clone.js  —  SÈL FICHYE OU BEZWEN EDITE POU PERSONALIZE
 * ======================================================
 *  Tout sa sit la ak bot la montre (non, logo, nimewo pwopriyetè,
 *  lyen gwoup, koulè, tèks ...) li soti isit la.
 *
 *  Ou ka itilize sa yo nan nenpòt tèks anba a:
 *    {name}         -> brand.name
 *    {botName}      -> brand.botName
 *    {owner}        -> brand.owner
 *    {developer}    -> brand.developer
 *    {ownerNumber}  -> nimewo pwopriyetè a (ak +)
 *    {group}        -> lyen gwoup WhatsApp la
 *    {prefix}       -> prefiks kòmand yo (egzanp .)
 *    {year}         -> ane an kou
 *
 *  Kite yon tèks vid ('') pou fèmen pati sa a.
 */

module.exports = {

  // ------------------------------------------------------------
  //  BRANDING
  // ------------------------------------------------------------
  brand: {
    name: 'DIMi md-X HOMMIE',
    botName: 'DIMi md-X HOMMIE',
    owner: 'DIMi-X HOMMIE',
    developer: 'DIMi-XHOMMIExTahyga',
    siteTitle: '{name}',          // tit nan ba anwo a (toujou an MAJIskil)
  },

  // ------------------------------------------------------------
  //  LOGO  (mete yon fichye logo.png nan rasin pwojè a, oswa itilize lyen an)
  // ------------------------------------------------------------
  logo: {
    url: 'https://files.catbox.moe/4h8mbh.jpg',
  },

  // ------------------------------------------------------------
  //  VIDEO  (voye ak repons .alive ak .ping — lyen dirèk yon fichye .mp4)
  //  Kite vid ('') pou voye sèlman tèks la. Pi piti videyo a ye, pi vit repons lan ye (< 5 MB).
  // ------------------------------------------------------------
  media: {
    video: 'https://files.catbox.moe/2ltftf.mp4',
  },

  // ------------------------------------------------------------
  //  PWOPRIYETÈ  (kòmand .owner + kòmand ki pou pwopriyetè sèlman)
  // ------------------------------------------------------------
  owner: {
    name: 'DIMi md-X HOMMIE',
    number: '+50936737679',
  },

  // ------------------------------------------------------------
  //  GWOUP WHATSAPP  (parèt anba kèk repons bot la voye)
  // ------------------------------------------------------------
  group: {
    link: 'https://chat.whatsapp.com/E8Bh0pL3q8NBn6WqDCDiaL?s=cl&p=a&iam=2',
  },

  // ------------------------------------------------------------
  //  BOT
  // ------------------------------------------------------------
  bot: {
    prefix: '.',

    // Kantite nimewo maksimòm ki ka konekte sou menm sèvè a.
    // Plan gratis Render = 512 MB RAM, kenbe l ba (8-10). Ou ka chanje l ak varyab MAX_SESSIONS.
    maxSessions: 10,

    // Mesaj ki voye nan WhatsApp moun nan lè koneksyon an fini.
    welcome:
      '✅ *{name}* konekte ak siksè !\n\n' +
      'Bot la aktif sou nimewo ou kounye a.\n' +
      '• Voye *{prefix}menu* pou wè tout kòmand yo.\n' +
      '• Voye *{prefix}logout* pou dekonekte l (oswa retire aparèy la nan WhatsApp > Aparèy konekte).',

    // Liy ki parèt anba kèk repons (menu, alive, owner, group, mesaj bienvini).
    // Si group.link vid, liy sa a pa parèt ditou.
    footer: '🔗 Rejwenn gwoup nou an :\n{group}',
  },

  // ------------------------------------------------------------
  //  SIT WEB
  // ------------------------------------------------------------
  website: {
    badge: 'Koneksyon pa kòd 8 chif',
    title: 'Konekte bot ou nan yon minit !',
    description:
      'Antre nimewo WhatsApp ou, pran yon kòd 8 chif epi lye {name} ak kont ou. Pa gen okenn Session ID pou kopye.',
    footer: '{name} • Fèt pa <b>{developer}</b> • Pwopriyetè : <b>{ownerNumber}</b>',
  },

  // ------------------------------------------------------------
  //  TÈM  (koulè + layout + mode)
  // ------------------------------------------------------------
  theme: {
    color: 'green',      // green, blue, red, purple, orange, pink, cyan, gold ... oswa '#ff0055'
    layout: 'modern',    // modern | gradient | glass | minimal | cyber
    mode: 'dark',        // dark | light
  },
};
