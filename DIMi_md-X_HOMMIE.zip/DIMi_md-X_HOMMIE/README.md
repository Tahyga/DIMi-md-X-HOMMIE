# DIMi md-X HOMMIE

Bot WhatsApp ak yon paj koneksyon : moun nan antre nimewo li, pran yon **kòd 8 chif**, epi antre l nan
WhatsApp > Aparèy konekte. Pa gen Session ID. Sesyon yo sere sou sèvè a (dosye `sessions/`) epi yo rekonekte otomatikman lè sèvè a rdemare.

## Fichye ki enpòtan

| Fichye | Wòl |
|---|---|
| `clone.js` | **Tout konfigirasyon** : non, logo, videyo (`.alive`/`.ping`), nimewo pwopriyetè, lyen gwoup, prefiks, tèks sit la, koulè |
| `commands.js` | **Kòmand bot la** — ajoute pa w yo isit la (gade egzanp anndan fichye a) |
| `handler.js` | Resevwa mesaj yo epi lanse kòmand yo |
| `manager.js` | Kenbe chak nimewo konekte, jere kòd koneksyon an ak rekonèksyon |
| `pair.js` / `index.js` | Sèvè web (paj koneksyon + `/health`) |
| `views/` | Paj HTML yo |

## Kòmand yo

`.menu` `.ping` `.alive` `.runtime` `.owner` `.group` `.logout` (mèt kont lan sèlman) `.users` (pwopriyetè a sèlman)

Lyen gwoup la parèt anba : mesaj bienvini an, `.menu`, `.alive`, `.owner` ak `.group`.

## Deplwaye sou Render

1. Mete pwojè a sou GitHub (`git add . && git commit -m "DIMi md-X HOMMIE" && git push`).
2. Sou Render : **New + → Blueprint** (li li `render.yaml`) oswa **New + → Web Service** :
   - Build Command : `npm install --omit=dev`
   - Start Command : `npm start`
   - Health Check Path : `/health`
   - Varyab : `NODE_VERSION=22`
3. Louvri URL Render la → **Konekte nimewo ou**.

### Varyab opsyonèl

| Varyab | Sa l fè | Default |
|---|---|---|
| `MAX_SESSIONS` | Kantite nimewo maksimòm konekte an menm tan | `10` |
| `SESSIONS_DIR` | Kote sesyon yo sere (itilize `/var/data/sessions` ak yon disk Render) | `./sessions` |
| `KEEP_ALIVE` | `0` pou fèmen ping otomatik la | aktif sou Render |
| `LOG_LEVEL` | `info` / `debug` pou wè plis log | `silent` |

### Bagay pou konnen sou Render

- **Plan gratis pa gen disk pèsistan** : chak redeploy/restart efase dosye `sessions/`, donk moun yo dwe konekte ankò. Pou kenbe sesyon yo : plan peye + disk (gade liy ki an komantè nan `render.yaml`).
- **Plan gratis dòmi** apre ~15 min san vizit. Bot la voye yon ping bay pwòp URL li chak 10 min (`RENDER_EXTERNAL_URL`) pou l rete reveye.
- Plan gratis gen 512 MB RAM : kenbe `MAX_SESSIONS` ba (8-10).

## Sekirite

- Dosye `sessions/` gen aksè konplè ak kont WhatsApp moun ki konekte yo. **Pa janm mete l sou GitHub** (li nan `.gitignore`) epi pa pataje l.
- Kòd koneksyon an limite a 5 demann pa IP chak 10 minit.
- Bot la pa sere kontni mesaj yo.
