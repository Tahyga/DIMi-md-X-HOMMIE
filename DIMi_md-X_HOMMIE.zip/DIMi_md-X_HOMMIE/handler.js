'use strict';
/**
 * handler.js
 *
 * Receives every incoming WhatsApp message, detects the command prefix and runs
 * the matching command from commands.js. You normally do not need to edit this
 * file: add your own commands in commands.js.
 */
const site = require('./site');
const commands = require('./commands');

const sentIds = new Set(); // ids of messages sent by the bot itself (to never react to them)
const lastUse = new Map(); // sender -> timestamp (simple anti-spam)

function remember(res) {
    const id = res && res.key && res.key.id;
    if (!id) return;
    sentIds.add(id);
    if (sentIds.size > 500) sentIds.delete(sentIds.values().next().value);
}

/** Send text, remembering the message id. */
async function sendText(sock, jid, text, quoted) {
    const res = await sock.sendMessage(jid, { text }, quoted ? { quoted } : undefined);
    remember(res);
    return res;
}

/** Send the logo with a caption; falls back to plain text if the image cannot be sent. */
async function sendWithLogo(sock, jid, caption, quoted) {
    const img = site.bot.logoSource();
    if (img) {
        try {
            const res = await sock.sendMessage(jid, { image: img, caption }, quoted ? { quoted } : undefined);
            remember(res);
            return res;
        } catch (e) {
            console.log('logo could not be sent, using text:', e && e.message);
        }
    }
    return sendText(sock, jid, caption, quoted);
}

/** Send a video with the text as its caption; falls back to plain text if the video cannot be sent. */
async function sendWithVideo(sock, jid, caption, quoted) {
    const vid = site.bot.videoSource();
    if (vid) {
        try {
            const res = await sock.sendMessage(jid, { video: vid, caption, mimetype: 'video/mp4' }, quoted ? { quoted } : undefined);
            remember(res);
            return res;
        } catch (e) {
            console.log('video could not be sent, using text:', e && e.message);
        }
    }
    return sendText(sock, jid, caption, quoted);
}

function unwrap(message) {
    let m = message;
    for (let i = 0; i < 4 && m; i++) {
        const next =
            (m.ephemeralMessage && m.ephemeralMessage.message) ||
            (m.viewOnceMessage && m.viewOnceMessage.message) ||
            (m.viewOnceMessageV2 && m.viewOnceMessageV2.message) ||
            (m.documentWithCaptionMessage && m.documentWithCaptionMessage.message);
        if (!next) break;
        m = next;
    }
    return m || {};
}

function textOf(msg) {
    return (
        msg.conversation ||
        (msg.extendedTextMessage && msg.extendedTextMessage.text) ||
        (msg.imageMessage && msg.imageMessage.caption) ||
        (msg.videoMessage && msg.videoMessage.caption) ||
        ''
    );
}

const digitsOf = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

/** Phone number (digits) of the sender, or '' when WhatsApp only exposed a LID. */
function senderNumber(sock, m) {
    if (m.key.fromMe) return digitsOf(sock.user && sock.user.id);
    const k = m.key;
    const candidates = [k.participantAlt, k.participantPn, k.participant, k.remoteJidAlt, k.remoteJid];
    for (const c of candidates) {
        if (c && String(c).endsWith('@s.whatsapp.net')) return digitsOf(c);
    }
    return '';
}

async function onMessages(sock, number, upsert) {
    if (!upsert || upsert.type !== 'notify') return;
    for (const m of upsert.messages || []) {
        try {
            await handleOne(sock, number, m);
        } catch (e) {
            console.log(`[${number}] command error:`, e && e.message);
        }
    }
}

async function handleOne(sock, number, m) {
    if (!m || !m.message || !m.key) return;
    const jid = m.key.remoteJid;
    if (!jid || jid === 'status@broadcast' || jid.endsWith('@newsletter')) return;
    if (m.key.id && sentIds.has(m.key.id)) return; // our own reply

    const body = textOf(unwrap(m.message)).trim();
    const prefix = site.bot.prefix;
    if (!body || !body.startsWith(prefix)) return;

    const parts = body.slice(prefix.length).trim().split(/\s+/);
    const name = (parts.shift() || '').toLowerCase();
    const cmd = commands.get(name);
    if (!cmd) return;

    const sender = senderNumber(sock, m);
    const who = number + ':' + (sender || jid);
    const now = Date.now();
    if (now - (lastUse.get(who) || 0) < 1200) return; // ignore flooding
    lastUse.set(who, now);
    if (lastUse.size > 2000) lastUse.delete(lastUse.keys().next().value);

    const isSelf = !!m.key.fromMe; // the account holder (the person who linked this number)
    const isOwner = !!sender && sender === site.bot.ownerDigits; // owner set in clone.js

    if (cmd.ownerOnly && !isOwner) return sendText(sock, jid, '⛔ Kòmand sa a se pou pwopriyetè bot la sèlman.', m);
    if (cmd.selfOnly && !isSelf) return sendText(sock, jid, '⛔ Se sèlman mèt kont WhatsApp sa a ki ka itilize kòmand sa a.', m);

    const ctx = {
        sock, m, jid, number, sender, isSelf, isOwner,
        args: parts,
        text: parts.join(' '),
        prefix,
        isGroup: jid.endsWith('@g.us'),
        reply: (text) => sendText(sock, jid, text, m),
        replyLogo: (caption) => sendWithLogo(sock, jid, caption, m),
        replyVideo: (caption) => sendWithVideo(sock, jid, caption, m),
        remember,
    };
    await cmd.run(ctx);
}

module.exports = { onMessages, sendText, sendWithLogo, sendWithVideo, handleOne };
