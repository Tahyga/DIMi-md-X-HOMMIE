/**
 * site.js
 *
 * Loads clone.js, fills in defaults for anything missing, and renders the
 * HTML pages in /views with the user's branding + theme, and exposes the
 * bot helpers (prefix, owner, group footer, logo). Edit clone.js, not this file.
 */
const fs = require('fs');
const path = require('path');

// ---------- defaults (used for anything missing in clone.js) ----------
const DEFAULTS = {
    brand: {
        name: 'DIMi md-X HOMMIE',
        botName: 'DIMi md-X HOMMIE',
        owner: 'DIMi md-X HOMMIE',
        developer: 'DIMi md-X HOMMIE',
        siteTitle: '{name}',
    },
    logo: { url: '' },
    media: { video: '' },
    owner: { name: '', number: '' },
    group: { link: '' },
    bot: {
        prefix: '.',
        maxSessions: 10,
        welcome: '\u2705 *{name}* konekte ak siksè !\n\nVoye *{prefix}menu* pou wè kòmand yo.',
        footer: '\ud83d\udd17 Rejwenn gwoup nou an :\n{group}',
    },
    website: {
        badge: 'Koneksyon pa kòd 8 chif',
        title: 'Konekte bot ou nan yon minit !',
        description: 'Antre nimewo WhatsApp ou, pran yon kòd 8 chif epi lye {name} ak kont ou.',
        footer: '{name} • Fèt pa <b>{developer}</b>',
    },
    theme: { color: 'green', layout: 'modern', mode: 'dark' },
};

let user = {};
try {
    user = require('./clone');
} catch (e) {
    console.log('[site] clone.js could not be loaded, using defaults:', e.message);
}

// deep merge; a value the user set (even '') always wins, undefined/null fall back
function merge(base, extra) {
    const out = {};
    for (const k of Object.keys(base)) {
        const b = base[k];
        const x = extra && extra[k];
        if (b && typeof b === 'object') out[k] = merge(b, x && typeof x === 'object' ? x : {});
        else if (x === undefined) out[k] = b;
        else if (x === null) out[k] = '';
        else out[k] = x;
    }
    return out;
}
const config = merge(DEFAULTS, user);

// ---------- helpers ----------
const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const ownerDigits = String(config.owner.number || '').replace(/[^0-9]/g, '');

const vars = {
    name: String(config.brand.name),
    botName: String(config.brand.botName),
    owner: String(config.brand.owner),
    developer: String(config.brand.developer),
    year: String(new Date().getFullYear()),
    prefix: String(config.bot.prefix || '.'),
    ownerNumber: ownerDigits ? '+' + ownerDigits : '',
    group: String(config.group.link || '').trim(),
};
// plain-text fill (WhatsApp messages)
const fill = (tpl) => String(tpl || '').replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
// html fill (values are escaped, the template itself may contain tags like <b>)
const fillHtml = (tpl) => String(tpl || '').replace(/\{(\w+)\}/g, (m, k) => (k in vars ? esc(vars[k]) : m));

// ---------- theme ----------
const LAYOUTS = ['modern', 'gradient', 'glass', 'minimal', 'cyber'];
const LAYOUT_ALIASES = { glassmorphism: 'glass', neon: 'cyber', cyberpunk: 'cyber', clean: 'minimal', default: 'modern' };

// friendly names -> nicer, brighter shades. Anything else is passed to CSS as-is
// (so every CSS colour name, hex, rgb() ... works too).
const COLOR_ALIASES = {
    green: '#00e676', blue: '#2979ff', red: '#ff1744', purple: '#aa5cff', orange: '#ff9100',
    pink: '#ff4081', cyan: '#00e5ff', yellow: '#ffea00', teal: '#1de9b6', gold: '#ffc400',
    lime: '#c6ff00', indigo: '#6c63ff', violet: '#b388ff', white: '#f5f5f5', black: '#2b2b2b',
    silver: '#cfd8dc', grey: '#90a4ae', gray: '#90a4ae', brown: '#c68642', maroon: '#e53950',
    navy: '#3d5afe', aqua: '#18ffff', magenta: '#ff2bd6', mint: '#69f0ae', sky: '#40c4ff',
    rose: '#ff5c8d', emerald: '#00e676', ruby: '#ff1744',
};

function pickTheme() {
    let layout = String(config.theme.layout || 'modern').trim().toLowerCase();
    layout = LAYOUT_ALIASES[layout] || layout;
    if (!LAYOUTS.includes(layout)) {
        console.log(`[site] Unknown layout "${config.theme.layout}". Use one of: ${LAYOUTS.join(', ')}. Using "modern".`);
        layout = 'modern';
    }
    const mode = String(config.theme.mode || 'dark').trim().toLowerCase() === 'light' ? 'light' : 'dark';
    const raw = String(config.theme.color || 'green').trim();
    let color = COLOR_ALIASES[raw.toLowerCase()] || raw;
    if (!/^[#a-zA-Z0-9(),.%\s/-]{1,60}$/.test(color)) color = COLOR_ALIASES.green; // sanitise
    return { layout, mode, color };
}

// ---------- logo ----------
function findLogo() {
    for (const ext of ['png', 'jpg', 'jpeg', 'webp', 'svg', 'gif', 'ico']) {
        const f = path.join(__dirname, 'logo.' + ext);
        if (fs.existsSync(f)) return f;
    }
    return null;
}
const logoFile = findLogo();
let logoSrc = '';
if (logoFile) logoSrc = '/brand-logo?v=' + Math.round(fs.statSync(logoFile).mtimeMs);
else if (config.logo.url && String(config.logo.url).trim()) logoSrc = String(config.logo.url).trim();

// ---------- bot helpers (used by manager.js / handler.js / commands.js) ----------
const bot = {
    prefix: vars.prefix,
    maxSessions: Math.max(1, Number(process.env.MAX_SESSIONS || config.bot.maxSessions) || 10),
    ownerDigits,
    ownerNumber: vars.ownerNumber,
    ownerName: String(config.owner.name || config.brand.owner),
    groupLink: vars.group,
    name: vars.name,
    botName: vars.botName,
    fill,
    // text of the footer line(s); '' when no group link is configured
    footer: () => (vars.group ? fill(config.bot.footer).trim() : ''),
    // add the footer (group link) at the bottom of a reply
    withFooter: (text) => {
        const f = vars.group ? fill(config.bot.footer).trim() : '';
        return f ? String(text).trimEnd() + '\n\n' + f : String(text);
    },
    welcome: () => bot.withFooter(fill(config.bot.welcome).trim()),
    // value usable as the `video` field of a WhatsApp message ({url}), or null
    videoSource: () => {
        const u = String(config.media.video || '').trim();
        return u ? { url: u } : null;
    },
    // value usable as the `image` field of a WhatsApp message (Buffer or {url}), or null
    logoSource: () => {
        if (logoFile) {
            try { return fs.readFileSync(logoFile); } catch (e) { /* fall through */ }
        }
        const u = String(config.logo.url || '').trim();
        return u ? { url: u } : null;
    },
};

// ---------- page rendering ----------
const headScript = `(function(){try{var d=document.documentElement,c=d.getAttribute('data-color');
if(!c||!window.CSS||!CSS.supports('color',c))return;d.style.setProperty('--accent',c);
var e=document.createElement('span');e.style.color=c;d.appendChild(e);var rgb=getComputedStyle(e).color;d.removeChild(e);
var m=rgb.match(/[\\d.]+/g);if(!m||m.length<3)return;var r=+m[0]/255,g=+m[1]/255,b=+m[2]/255;
var L=0.2126*r+0.7152*g+0.0722*b;d.style.setProperty('--on-accent',L>0.5?'#03130a':'#ffffff');
var mx=Math.max(r,g,b),mn=Math.min(r,g,b),h=0,s=0,l=(mx+mn)/2;
if(mx!==mn){var dl=mx-mn;s=l>.5?dl/(2-mx-mn):dl/(mx+mn);h=mx===r?(g-b)/dl+(g<b?6:0):mx===g?(b-r)/dl+2:(r-g)/dl+4;h*=60;}
h=s<.12?265:(h+50)%360;
d.style.setProperty('--accent-2','hsl('+Math.round(h)+','+Math.round(Math.max(s,.55)*100)+'%,'+Math.round(Math.min(Math.max(l,.45),.65)*100)+'%)');
}catch(x){}})();`;

const themeCss = fs.readFileSync(path.join(__dirname, 'views', 'theme.css'), 'utf8');
const cache = {};

function render(view) {
    if (cache[view]) return cache[view];
    const t = pickTheme();
    const html = fs.readFileSync(path.join(__dirname, 'views', view + '.html'), 'utf8');

    const logoImg = (alt) => (logoSrc ? `<img src="${esc(logoSrc)}" alt="${esc(alt)}" />` : '');
    const footerText = String(config.website.footer || '').trim();
    const txt = (v) => String(v || '').trim();
    const badgeIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l7 4v6c0 5-3.5 8.5-7 10-3.5-1.5-7-5-7-10V6l7-4z"/></svg>';

    const map = {
        HTML_ATTRS: `data-layout="${t.layout}" data-mode="${t.mode}" data-color="${esc(t.color)}"`,
        THEME_HEAD:
            (logoSrc ? `<link rel="icon" href="${esc(logoSrc)}" />\n` : '') +
            `<meta name="author" content="${esc(vars.owner)}" />\n` +
            `<style>\n${themeCss}\n</style>\n<script>${headScript}</script>`,
        BRAND: esc(vars.name),
        BOTNAME: esc(vars.botName),
        SITE_TITLE: esc(fill(config.brand.siteTitle)),
        NAV_LOGO: logoSrc
            ? `<a class="brand-logo" href="#home" aria-label="${esc(vars.name)}">${logoImg(vars.name + ' logo')}</a>`
            : '<span class="brand-logo brand-logo--empty"></span>',
        PAIR_LOGO: logoImg(vars.botName),
        HERO_BADGE: txt(config.website.badge) ? `<div class="badge">${badgeIcon} ${fillHtml(txt(config.website.badge))}</div>` : '',
        HERO_TITLE: txt(config.website.title) ? `<h1><b>${fillHtml(txt(config.website.title))}</b></h1>` : '',
        HERO_DESC: txt(config.website.description) ? `<p>${fillHtml(txt(config.website.description))}</p>` : '',
        FOOTER: footerText ? `<footer>\n  <p>${fillHtml(footerText)}</p>\n</footer>` : '',
        GROUP_LINK: esc(vars.group),
        GROUP_LINK_JSON: JSON.stringify(vars.group).replace(/</g, '\\u003c'),
        OWNER_NUMBER: esc(vars.ownerNumber),
    };
    cache[view] = html.replace(/\{\{(\w+)\}\}/g, (m, k) => (k in map ? map[k] : m));
    return cache[view];
}

module.exports = { config, render, bot, logoFile };
