'use strict';
const express = require('express');
const site = require('./site');
const manager = require('./manager');
const pairRouter = require('./pair');

const app = express();
const port = process.env.PORT || 8000;

app.set('trust proxy', 1); // Render / Railway / Heroku sit behind a proxy (real client IP for the rate limit)
app.disable('x-powered-by');
app.use((req, res, next) => {
    res.set({
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY',
        'Referrer-Policy': 'no-referrer',
    });
    next();
});
app.use(express.json({ limit: '10kb' }));

// health check (used by Render) — never exposes numbers
app.get('/health', (req, res) => {
    res.json({ ok: true, connected: manager.count().connected, uptime: Math.round(process.uptime()) });
});

// Logo: if you put logo.png (or .jpg/.webp/.svg...) in the root folder it is served here
app.get('/brand-logo', (req, res) => {
    if (!site.logoFile) return res.status(404).end();
    res.sendFile(site.logoFile);
});

app.use('/', pairRouter);

app.get('/pair', (req, res) => {
    res.type('html').send(site.render('pair'));
});

app.get('*', (req, res) => {
    res.type('html').send(site.render('main'));
});

// Never let one WhatsApp error crash the whole server (all linked numbers would go offline)
process.on('unhandledRejection', (err) => console.log('unhandledRejection:', err && (err.stack || err.message || err)));
process.on('uncaughtException', (err) => console.log('uncaughtException:', err && (err.stack || err.message || err)));

// Render free plan sleeps after ~15 min without visits: ping our own public URL so the bot stays awake.
// Disable with KEEP_ALIVE=0.
function keepAlive() {
    const url = process.env.RENDER_EXTERNAL_URL;
    if (!url || process.env.KEEP_ALIVE === '0') return;
    setInterval(() => {
        fetch(url.replace(/\/$/, '') + '/health', { signal: AbortSignal.timeout(15000) }).catch(() => {});
    }, 10 * 60 * 1000).unref();
    console.log('[keep-alive] pinging', url, 'every 10 min');
}

if (require.main === module) {
    app.listen(port, () => {
        console.log(`${site.bot.botName} ready on http://localhost:${port}`);
        manager.restoreAll().catch((e) => console.log('restoreAll failed:', e && e.message));
        keepAlive();
    });
}

module.exports = app;
